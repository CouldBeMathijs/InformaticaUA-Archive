//
// Created by mathijs on 12/18/24.
//

#include "Student.h"
#include "Cursus.h" // Include Cursus.h here
Student::Student(const string &voornaam, const string &achternaam, const string &rolnummer) : voornaam(voornaam),
                                                                                              achternaam(achternaam),
                                                                                              rolnummer(rolnummer) {}

const string &Student::getVoornaam() const {
    return voornaam;
}

const string &Student::getAchternaam() const {
    return achternaam;
}

const string &Student::getRolnummer() const {
    return rolnummer;
}

string Student::toString() const {
    return getVoornaam() + " " + getAchternaam() + " (" + getRolnummer() + ")";
}

int Student::getStudiepunten() {
    int out = 0;
    for (auto& cursus:cursussen) {
        out += cursus.second->getStudiepunten();
    }
    return out;
}

bool Student::schrijfUit(Cursus * oldCursus) {
    for (auto& cursus:cursussen) {
        if (cursus.second == oldCursus) {
            oldCursus->verwijder(this);
            cursussen.erase(oldCursus->getAfkorting());
            return true;
        }
    }
    return false;
}

bool Student::schrijfIn(Cursus * cursus) {
    if (this->getStudiepunten() + cursus->getStudiepunten() > 60) {
        return false;
    }
    cursussen[cursus->getAfkorting()] = cursus;
    cursus->voegToe(this);
    return true;
}



