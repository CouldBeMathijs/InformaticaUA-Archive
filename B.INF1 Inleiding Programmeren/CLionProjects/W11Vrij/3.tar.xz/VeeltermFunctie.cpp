#include "VeeltermFunctie.h"
#include <sstream>
#include <cmath>
using namespace std;
const string &VeeltermFunctie::getNaam() const {
    return naam;
}

void VeeltermFunctie::setNaam(const string &naam) {
    VeeltermFunctie::naam = naam;
}
int VeeltermFunctie::getGraad() const{
    return VeeltermFunctie::coefficienten.size() - 1;
}

void VeeltermFunctie::setCoefficienten(const vector<int> &coefficienten) {
    VeeltermFunctie::coefficienten = coefficienten;
}

#include <sstream> // Voor ostringstream
#include <vector>
#include <string>

#include <sstream> // Voor ostringstream
#include <vector>
#include <string>
#include <cmath> // Voor abs

string VeeltermFunctie::toString() const {
    ostringstream oss;
    oss << naam << "(x) = ";

    // Loop door de coëfficiënten en bouw de string op
    for (int i = getGraad(); i >= 0; --i) {
        int coeff = coefficienten[i];
        if (coeff != 0) { // Alleen niet-nul coëfficiënten toevoegen
            if (i < getGraad()) { // Voeg een '+' toe als het niet de eerste term is
                oss << (coeff > 0 ? " + " : " - ");
            }
            // Voeg de absolute waarde van de coëfficiënt toe
            oss << abs(coeff);
            // Voeg de macht van x toe, indien nodig
            if (i > 0) {
                oss << " x";
                if (i > 1) {
                    oss << "^" << i; // Voeg de macht toe als het groter is dan 1
                }
            }
        }
    }

    return oss.str(); // Geef de geconstrueerde string terug
}

double VeeltermFunctie::berekenFunctiewaarde(double x) {
    double out = 0;
    for (int i = 0; i < coefficienten.size(); i++){
        out += coefficienten[i] * pow(x, i);
    }
    return out;
}

VeeltermFunctie VeeltermFunctie::berekenAfgeleide(){
    string newnaam = naam + "'";
    vector<int> newcoef;

    for (size_t i = 1; i < coefficienten.size(); ++i) {
        newcoef.push_back(coefficienten[i] * i);
    }
    return VeeltermFunctie(newnaam, newcoef);
}

VeeltermFunctie::VeeltermFunctie() {}

VeeltermFunctie::VeeltermFunctie(const string &naam) : naam(naam) {}


VeeltermFunctie::VeeltermFunctie(const string &naam, const vector<int> &coefficienten) : naam(naam),
                                                                                         coefficienten(coefficienten) {}

const vector<int> &VeeltermFunctie::getCoefficienten() const {
    return coefficienten;
}

void VeeltermFunctie::som(const VeeltermFunctie opteller) {
    int grootste;
    vector<int> const &optellercoef = opteller.getCoefficienten();
    if (optellercoef >= this->coefficienten){
        grootste = optellercoef.size();
    } else {
        grootste = this->coefficienten.size();
    }
    for (int i=0; i > grootste; i++) {
        coefficienten[i] += optellercoef[i];
    }
    // Voeg de overige getallen van de opteller toe aan de main
    for (int i = coefficienten.size(); i > optellercoef.size(); i++){
        coefficienten.push_back(optellercoef[i]);
    }
}

void VeeltermFunctie::product(const VeeltermFunctie tevermenigvuldigen) {

}


