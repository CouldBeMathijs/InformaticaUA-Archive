#ifndef W11VRIJ_VEELTERMFUNCTIE_H
#define W11VRIJ_VEELTERMFUNCTIE_H
#include <string>
#include <vector>
using namespace std;
class VeeltermFunctie {
private:
    string naam;
    vector<int> coefficienten;

    vector<int> calculateProduct(const vector<int>& a, const vector<int>& b) const;

    void multiplyAndAddToResult(int coefA, size_t indexA, const vector<int>& b, vector<int>& result) const;

public:
    const string &getNaam() const;

    void setNaam(const string &naam);

    int getGraad() const;

    void setCoefficienten(const vector<int> &coefficienten);

    string toString() const;

    double berekenFunctiewaarde(double x);

    VeeltermFunctie berekenAfgeleide();

    VeeltermFunctie();

    explicit VeeltermFunctie(const string &naam);

    VeeltermFunctie(const string &naam, const vector<int> &coefficienten);

    const vector<int> &getCoefficienten() const;

    void som(const VeeltermFunctie optetellen);

    void product(const VeeltermFunctie tevermenigvuldigen);

    };


#endif //W11VRIJ_VEELTERMFUNCTIE_H
