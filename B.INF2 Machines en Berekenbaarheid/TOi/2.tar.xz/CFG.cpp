
#include "CFG.h"

#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include "json.hpp"


CFG::CFG(const std::string& file)
{
    std::ifstream input(file);
    if (!input)
    {
        throw std::invalid_argument("File " + file + " not found");
    }
    using json = nlohmann::json;
    json j;
    input >> j;

    for (const auto& var : j["Variables"]) {
        if (var.is_string()) {
            variables.insert(var.get<std::string>());
        }
    }

    for (const auto& term : j["Terminals"]) {
        if (term.is_string()) {
            terminals.insert(term.get<std::string>());
        }
    }
    for (const auto& prod_obj : j["Productions"]) {
        if (prod_obj.is_object() && prod_obj.contains("head") && prod_obj.contains("body")) {
            auto head = prod_obj["head"].get<std::string>();
            std::vector<std::string> body_vec;
            if (prod_obj["body"].is_array()) {
                for (const auto& symbol : prod_obj["body"]) {
                    if (symbol.is_string()) {
                        body_vec.push_back(symbol.get<std::string>());
                    }
                }
            }
            productions[head].push_back(body_vec);
        }
    }

    startsymbol = j["Start"].get<std::string>();
}

CFG::CFG(const std::set<std::string>& variables, const std::set<std::string>& terminals,
    const std::unordered_map<std::string, std::vector<std::vector<std::string>>>& productions,
    const std::string& startsymbol): variables(variables),
                                     terminals(terminals),
                                     productions(productions),
                                     startsymbol(startsymbol)
{
}

std::string CFG::toString()
{
    std::stringstream result;

    // Print Variables (V)
    result << "V = {";
    bool first = true;
    for (const auto& var : variables) {
        if (!first) {
            result << ", ";
        }
        result << var;
        first = false;
    }
    result << "}\n";

    // Print Terminals (T)
    result << "T = {";
    first = true;
    for (const auto& term : terminals) {
        if (!first) {
            result << ", ";
        }
        result << term;
        first = false;
    }
    result << "}\n";

    result << "P = {\n";

    std::vector<std::string> productionKeys;
    for (const auto& pair : productions) {
        productionKeys.push_back(pair.first);
    }
    std::sort(productionKeys.begin(), productionKeys.end());

    for (const auto& key : productionKeys) {
        std::vector<std::vector<std::string>> sorted_bodies = productions.at(key);
        std::sort(sorted_bodies.begin(), sorted_bodies.end());
        for (const auto& bodies : sorted_bodies) {
            result << "    " << key << " -> `";
            bool first_symbol = true;
            if (bodies.empty()) {
                result << "";
            } else {
                for (const auto& symbol : bodies) {
                    if (!first_symbol) {
                        result << " ";
                    }
                    result << symbol;
                    first_symbol = false;
                }
            }
            result << "`\n";
        }
    }

    result << "}\n";

    result << "S = " << startsymbol;

    return result.str();
}

void CFG::print()
{
    std::cout << this->toString() << std::endl;
}
