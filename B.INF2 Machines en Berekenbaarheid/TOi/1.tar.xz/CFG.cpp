
#include "CFG.h"

CFG::CFG()
{
    Variables = {"BINDIGIT", "S"};
    Terminals = {"0", "1", "a", "b"};

    Productions["BINDIGIT"].emplace_back("`0`");
    Productions["BINDIGIT"].emplace_back("`1`");
    Productions["S"].emplace_back("``");
    Productions["S"].emplace_back("`a S b BINDIGIT`");

    StartSymbol = "S";
}

CFG::CFG(const std::set<std::string>& variables, const std::set<std::string>& terminals,
    const std::unordered_map<std::string, std::vector<std::string>>& productions, const std::string& start_symbol): Variables(variables),
    Terminals(terminals),
    Productions(productions),
    StartSymbol(start_symbol)
{
}

std::string CFG::toString()
{
    std::stringstream result;

    result << "V = {";
    bool first = true;
    for (const auto& var : Variables) {
        if (!first) {
            result << ", ";
        }
        result << var;
        first = false;
    }
    result << "}\n";

    result << "T = {";
    first = true;
    for (const auto& term : Terminals) {
        if (!first) {
            result << ", ";
        }
        result << term;
        first = false;
    }
    result << "}\n";

    result << "P = {\n";

    std::vector<std::string> productionKeys;
    for (const auto& pair : Productions) {
        productionKeys.push_back(pair.first);
    }
    std::sort(productionKeys.begin(), productionKeys.end());

    for (const auto& key : productionKeys) {
        for (const auto& production : Productions[key]) {
            result << "    " << key << " -> " << production << "\n";
        }
    }

    result << "}\n";

    result << "S = " << StartSymbol;

    return result.str();
}

void CFG::print()
{
    std::cout << this->toString() << std::endl;
}
