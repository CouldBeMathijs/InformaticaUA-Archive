#ifndef PROGRAMMEEROPDRACHT_CFG_H
#define PROGRAMMEEROPDRACHT_CFG_H
#include <iostream>
#include <set>
#include <string>
#include <unordered_map>
#include <sstream>
#include <vector>
#include <algorithm>

class CFG
{
private:
    std::set<std::string> Variables;
    std::set<std::string> Terminals;
    std::unordered_map<std::string, std::vector<std::string>> Productions;
    std::string StartSymbol;

public:
    CFG();

    CFG(const std::set<std::string>& variables, const std::set<std::string>& terminals,
        const std::unordered_map<std::string, std::vector<std::string>>& productions, const std::string& start_symbol);

    std::string toString();

    void print();
};


#endif //PROGRAMMEEROPDRACHT_CFG_H
