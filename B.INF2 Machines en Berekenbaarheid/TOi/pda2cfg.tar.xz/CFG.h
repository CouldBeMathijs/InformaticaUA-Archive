#ifndef PROGRAMMEEROPDRACHT_CFG_H
#define PROGRAMMEEROPDRACHT_CFG_H
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

class CFG {
private:
    std::set<std::string> variables;
    std::set<std::string> terminals;
    std::unordered_map<std::string, std::vector<std::vector<std::string> > > productions;
    std::string startsymbol;

public:
    explicit CFG(const std::string &);

    CFG() = default;

    CFG(const std::set<std::string> &variables, const std::set<std::string> &terminals,
        const std::unordered_map<std::string, std::vector<std::vector<std::string> > > &productions,
        const std::string &startsymbol);

    std::string toString();

    void print();
};


#endif //PROGRAMMEEROPDRACHT_CFG_H
